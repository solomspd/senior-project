#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(acos(b))*(fmin(a,b));
e=floor(b);
e=cos(a);
b=(acos(b))/(fmin(e,b));
a=exp(b);
while(isless(e,a)){
d=(asin(d))+(pow(c,d));
a=pow(d,e);
a=(tan(e))-(floor(c));
}
a=log10(c);
d=(fmax(d,a))*(tan(e));
a=fmax(c,a);
d=fmin(b,e);
a=(fmax(a,b))/(atan2(b,a));
}