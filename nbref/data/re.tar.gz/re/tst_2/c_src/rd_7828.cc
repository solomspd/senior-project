#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(fmax(b,b))-(pow(c,d));
e=(floor(a))-(ceil(h));
c=pow(a,c);
c=(atan(b))/(tan(b));
b=(pow(a,c))/(cos(b));
h=cos(g);
d=exp(g);
if(islessequal(b,b)){
e=fmin(g,d);
e=pow(d,g);
g=atan2(b,a);
a=cos(g);
a=(fmin(b,a))-(exp(d));
}
}