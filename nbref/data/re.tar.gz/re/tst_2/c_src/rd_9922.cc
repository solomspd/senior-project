#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(exp(b))/(fmax(f,g));
e=(exp(f))*(fdim(a,e));
c=fmax(d,c);
if(isgreaterequal(f,d)){
a=(pow(b,d))-(fdim(f,c));
d=tan(c);
f=(tan(e))-(atan2(c,a));
e=fmax(d,g);
g=fdim(b,g);
}
if(islessgreater(f,d)){
c=(fdim(c,g))-(atan2(a,f));
b=acos(c);
d=(exp(d))+(exp(b));
}
else{
f=log(a);
g=(fmax(a,g))-(fdim(b,a));
d=(fmax(g,b))-(fmin(g,d));
e=sqrt(c);
e=pow(a,a);
}
}