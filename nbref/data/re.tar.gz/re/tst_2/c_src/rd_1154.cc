#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(tan(d))-(log(c));
a=exp(c);
a=fdim(d,b);
c=(atan(b))/(pow(a,c));
d=(sin(d))*(cos(c));
while(isgreaterequal(d,d)){
e=(fdim(e,b))-(fmin(d,b));
b=(fmin(b,b))/(atan2(e,b));
b=(pow(c,b))+(atan2(d,b));
e=(fdim(b,b))/(sin(c));
b=sqrt(e);
}
d=fdim(d,b);
b=(fdim(c,a))*(floor(c));
e=(log10(b))+(atan2(c,b));
b=pow(b,c);
b=(fmin(a,a))/(sqrt(e));
}