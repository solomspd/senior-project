#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=fmax(a,d);
h=cos(e);
a=(floor(h))*(exp(h));
c=(acos(f))+(atan2(f,c));
if(isless(a,d)){
e=(asin(c))+(fdim(g,b));
e=fdim(b,d);
}
else{
g=(exp(h))-(floor(a));
c=log(f);
d=atan2(a,c);
f=exp(c);
c=(pow(e,f))*(fdim(g,h));
}
c=(sin(e))+(pow(c,e));
a=(sqrt(b))/(cos(h));
}