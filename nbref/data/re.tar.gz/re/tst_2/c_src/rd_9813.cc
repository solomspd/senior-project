#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(atan(a))/(pow(d,b));
c=(fmax(d,f))/(atan2(f,a));
e=fmax(e,b);
a=(atan(c))/(tan(d));
b=(fmin(d,c))*(log10(f));
b=(floor(e))-(tan(f));
if(isless(f,d)){
d=(fmin(f,d))-(fmax(a,b));
c=fmin(b,b);
d=cos(c);
}
else{
d=log(b);
f=fmax(f,b);
d=fdim(d,e);
b=fmin(f,a);
}
}