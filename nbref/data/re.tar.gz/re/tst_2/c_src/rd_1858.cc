#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=atan2(e,d);
a=(fmax(b,e))-(exp(d));
d=fmax(a,c);
c=(atan2(b,e))+(fdim(a,e));
c=(exp(a))-(pow(d,b));
a=log10(b);
c=atan2(e,a);
c=sin(a);
a=(pow(b,c))/(pow(a,d));
b=(sqrt(a))+(log(d));
while(islessgreater(e,a)){
a=fmax(c,d);
c=fmin(e,b);
a=(fmin(e,b))-(sqrt(c));
e=sin(b);
}
}