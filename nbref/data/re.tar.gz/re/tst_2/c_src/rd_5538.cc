#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(log10(b))+(asin(e));
e=(pow(e,c))+(fmin(c,e));
while(islessgreater(e,b)){
c=(log(d))-(floor(d));
e=(fmin(d,e))-(pow(b,c));
a=(fmax(c,a))-(sin(d));
c=(sin(a))*(atan2(d,b));
}
while(isgreaterequal(b,c)){
c=(fdim(e,d))+(ceil(d));
a=atan2(e,d);
d=(fmax(e,a))-(ceil(a));
b=atan2(c,a);
}
}