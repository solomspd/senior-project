#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=atan2(b,a);
d=(ceil(b))-(fmax(d,c));
c=fmax(c,a);
c=(log10(c))+(fdim(d,a));
b=(pow(d,d))/(pow(a,d));
d=log10(c);
b=cos(d);
e=exp(d);
b=sin(b);
a=fmin(e,c);
a=fmax(b,b);
b=log10(c);
}