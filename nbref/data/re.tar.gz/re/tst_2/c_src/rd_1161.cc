#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(atan2(c,g))/(fmax(g,b));
c=(cos(b))+(fdim(c,e));
g=floor(e);
while(isless(c,f)){
a=(tan(d))*(fdim(d,b));
f=(atan2(g,g))*(atan(f));
a=fmax(f,f);
e=fmin(g,e);
d=pow(d,c);
}
e=sqrt(f);
g=(fdim(c,d))*(sin(e));
}