#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=pow(c,d);
f=(fmin(d,b))*(pow(b,a));
e=(atan2(f,f))+(fmin(c,c));
b=(fmax(b,d))-(pow(d,g));
a=(exp(d))/(fdim(d,f));
d=fdim(g,c);
e=ceil(f);
if(islessequal(a,d)){
g=ceil(g);
d=sin(b);
f=fmin(d,g);
}
}