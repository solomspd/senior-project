#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=atan2(c,d);
b=fmin(a,c);
if(isless(e,e)){
d=(sin(d))/(atan2(d,a));
c=fmin(e,c);
b=(ceil(e))+(exp(a));
}
while(isless(d,c)){
d=cos(d);
a=(fdim(c,e))/(log(b));
e=(fmax(e,e))+(fdim(c,c));
b=(acos(d))+(atan2(c,d));
}
}