#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=(tan(f))*(exp(g));
b=atan(b);
b=fmax(d,e);
a=ceil(c);
if(isless(c,b)){
b=(fdim(d,a))+(asin(a));
a=acos(b);
g=(fdim(d,b))+(cos(f));
b=pow(e,d);
d=sin(c);
}
else{
a=fmax(b,e);
g=(fmin(e,g))*(atan(c));
f=(floor(b))-(asin(a));
b=log10(d);
}
if(isless(f,a)){
e=log10(a);
a=(fmin(e,b))*(fmax(f,f));
c=(fmin(c,c))*(fdim(d,b));
c=asin(c);
d=sin(e);
}
else{
a=sin(d);
c=(cos(d))*(sin(b));
f=(floor(c))-(sqrt(d));
}
}