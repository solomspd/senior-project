#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=atan(d);
b=(fdim(e,a))+(sin(e));
while(isgreaterequal(d,g)){
f=(floor(b))*(fdim(a,f));
g=(pow(g,e))-(atan(g));
}
while(isgreaterequal(b,g)){
c=(floor(b))/(fmin(d,c));
d=(acos(e))/(floor(f));
c=asin(f);
}
}