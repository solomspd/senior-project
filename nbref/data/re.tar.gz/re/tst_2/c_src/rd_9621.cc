#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(log(d))-(pow(e,a));
b=fmin(a,d);
b=(fmax(d,c))/(atan(a));
if(isgreaterequal(c,e)){
b=exp(c);
c=(fmax(a,e))-(fmin(e,d));
d=(log(e))-(ceil(a));
d=(ceil(b))/(log10(a));
}
else{
b=atan2(d,e);
c=(fmin(d,e))+(cos(d));
d=(exp(b))*(floor(d));
}
if(isgreaterequal(e,c)){
d=(asin(b))/(cos(c));
e=(tan(e))/(exp(b));
d=atan2(c,d);
}
}