#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=atan2(c,e);
d=fmax(c,f);
if(isgreaterequal(c,d)){
e=(fmax(d,b))/(pow(b,b));
d=(fmax(b,b))*(pow(b,f));
f=acos(d);
c=(sqrt(e))-(fdim(f,a));
}
else{
c=log10(e);
d=atan2(b,e);
e=pow(e,a);
}
if(islessequal(b,f)){
c=fmax(e,d);
e=(log(e))+(pow(e,b));
d=sin(b);
e=atan2(c,d);
}
}