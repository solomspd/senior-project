#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=cos(a);
e=pow(b,e);
d=(atan2(e,d))/(tan(c));
c=atan2(c,e);
if(isless(c,c)){
c=(pow(d,d))*(pow(e,e));
e=asin(e);
b=tan(e);
c=(fmax(e,c))/(acos(e));
d=(fmax(a,b))*(atan2(a,b));
}
else{
e=(atan2(d,c))/(pow(b,e));
b=fdim(b,d);
b=(fmax(e,b))+(fmin(b,c));
c=(asin(a))/(atan2(a,c));
d=fdim(b,a);
}
if(isgreaterequal(a,a)){
e=(log10(b))/(pow(a,e));
d=(log(b))+(atan2(e,b));
}
}