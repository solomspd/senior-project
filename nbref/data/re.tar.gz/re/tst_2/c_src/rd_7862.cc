#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=(atan2(d,b))-(atan(f));
c=log(b);
d=exp(e);
e=log(d);
while(isless(a,a)){
f=(fmin(d,d))/(cos(d));
d=(atan2(f,d))+(cos(a));
c=asin(f);
}
while(islessgreater(a,e)){
a=(atan2(e,f))-(fdim(d,c));
d=(exp(d))-(fmax(d,b));
b=fmax(b,a);
a=cos(d);
}
}