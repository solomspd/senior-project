#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmax(b,f);
d=(log(c))*(log10(a));
a=(sin(b))*(pow(c,a));
d=(atan2(a,b))+(exp(b));
c=fmin(e,d);
d=(atan2(d,f))*(exp(e));
d=(fdim(f,b))/(fmax(d,c));
b=fmax(f,b);
c=(fmax(e,f))/(floor(b));
if(islessgreater(f,e)){
d=(tan(d))*(fmax(f,f));
d=(fmin(d,a))/(atan2(f,d));
}
}