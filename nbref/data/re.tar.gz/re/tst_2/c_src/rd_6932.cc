#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=acos(d);
e=(cos(d))/(sin(d));
while(islessgreater(b,e)){
b=log10(b);
e=atan2(b,e);
}
if(islessequal(b,d)){
b=(sqrt(b))/(fmin(a,a));
a=atan2(d,d);
}
}