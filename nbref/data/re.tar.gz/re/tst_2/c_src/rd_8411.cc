#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(fdim(e,g))-(log10(g));
f=fmin(a,b);
e=atan2(c,e);
e=(cos(a))*(fmin(c,c));
b=atan2(f,g);
a=fmax(a,c);
b=fdim(d,f);
e=fdim(b,e);
f=exp(e);
while(islessequal(d,g)){
b=(fmax(b,g))+(fdim(g,e));
a=fmax(a,d);
a=cos(d);
a=(sqrt(a))/(log(b));
}
}