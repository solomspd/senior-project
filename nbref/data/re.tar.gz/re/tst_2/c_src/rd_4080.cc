#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(fmin(b,e))*(floor(g));
g=fmax(b,d);
f=fmin(d,d);
b=sin(d);
b=acos(g);
a=fmax(c,g);
g=fdim(e,a);
d=(log(f))*(ceil(g));
f=exp(g);
g=(ceil(g))/(fmin(e,g));
}