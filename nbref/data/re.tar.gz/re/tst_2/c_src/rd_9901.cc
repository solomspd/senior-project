#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=pow(e,f);
e=(pow(b,h))-(log10(h));
d=(sqrt(a))/(atan(a));
d=log(g);
c=(cos(d))-(cos(h));
e=(atan2(f,f))-(pow(g,c));
b=cos(b);
f=(log(a))+(pow(g,c));
}