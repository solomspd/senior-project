#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=log10(c);
b=(sqrt(a))+(atan2(e,d));
b=exp(d);
b=floor(c);
while(islessgreater(d,b)){
a=(fdim(c,a))+(tan(d));
c=(atan(e))-(fmin(e,c));
}
if(islessgreater(d,c)){
b=exp(d);
e=(atan2(c,c))*(fmin(a,b));
}
else{
d=(fmax(b,d))*(fmax(e,c));
e=(tan(b))+(exp(b));
a=fmax(a,e);
}
}