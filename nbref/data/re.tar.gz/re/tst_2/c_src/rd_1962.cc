#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(asin(d))-(sin(f));
f=(sqrt(c))+(fmax(e,b));
g=(fmax(a,e))/(atan2(g,f));
g=(sqrt(b))-(fdim(c,b));
g=ceil(g);
while(isgreaterequal(c,a)){
a=sqrt(c);
b=(fmax(c,g))+(cos(c));
g=pow(b,c);
b=(fmax(a,f))/(fmin(f,e));
}
b=fdim(f,b);
f=(log10(b))/(fmin(f,a));
e=asin(g);
c=fdim(a,d);
g=cos(a);
}