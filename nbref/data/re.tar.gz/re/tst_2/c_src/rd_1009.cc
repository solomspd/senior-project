#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=asin(f);
a=(log10(h))*(asin(c));
b=(pow(a,e))-(cos(f));
e=fdim(f,h);
if(islessequal(g,g)){
e=(atan(d))*(sqrt(e));
d=fdim(c,g);
}
if(islessequal(e,g)){
b=(fmax(f,h))*(pow(a,f));
h=fmin(g,g);
}
else{
g=exp(b);
a=ceil(h);
b=fmax(a,f);
a=(pow(a,g))/(fmin(h,g));
c=(cos(a))+(fmin(f,d));
}
}