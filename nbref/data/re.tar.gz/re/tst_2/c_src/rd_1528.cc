#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(atan2(b,e))+(fdim(b,e));
c=log10(a);
b=(fdim(e,a))*(atan2(b,c));
a=(fmax(a,c))/(fmin(e,d));
d=(sin(d))*(acos(a));
e=(ceil(a))*(sin(c));
d=acos(b);
b=fdim(c,b);
b=(tan(d))-(exp(a));
e=(fdim(c,b))*(cos(a));
while(isgreaterequal(e,c)){
d=acos(e);
c=(fmin(c,c))/(atan2(e,a));
}
}