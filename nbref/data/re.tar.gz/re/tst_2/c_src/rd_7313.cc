#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmin(a,c))*(fmin(d,e));
b=(tan(e))/(pow(a,c));
e=fdim(d,a);
d=atan2(e,a);
c=(floor(c))-(ceil(e));
e=cos(c);
c=atan2(e,e);
if(islessgreater(d,b)){
d=fmax(a,c);
c=(fdim(a,c))+(atan2(c,c));
}
else{
b=ceil(a);
c=(acos(a))-(fmin(e,c));
}
}