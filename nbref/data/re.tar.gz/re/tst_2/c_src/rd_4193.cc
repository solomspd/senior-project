#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(fdim(a,d))*(fdim(d,b));
c=(atan2(a,c))+(fmax(d,c));
c=(fmin(c,b))+(tan(c));
b=fdim(c,c);
c=(fmin(a,d))+(exp(c));
d=tan(b);
d=(pow(b,a))+(fmin(a,e));
e=atan2(c,a);
b=atan2(a,a);
e=(tan(e))*(ceil(d));
}