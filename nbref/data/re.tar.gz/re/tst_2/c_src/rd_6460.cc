#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(fmin(c,e))*(acos(f));
f=fdim(c,b);
c=(pow(b,c))-(pow(d,f));
b=(fmax(a,d))+(cos(a));
while(islessgreater(e,d)){
e=(fdim(a,a))+(fmax(a,b));
a=atan(c);
}
if(isgreaterequal(a,d)){
e=(exp(b))*(atan2(c,c));
c=exp(f);
c=atan(a);
b=(fmax(d,d))+(sin(a));
f=sqrt(e);
}
else{
e=sqrt(d);
f=(cos(e))*(fmin(f,b));
d=(fdim(a,e))-(sin(a));
f=(pow(f,f))/(acos(c));
f=(pow(d,f))/(fdim(c,a));
}
}