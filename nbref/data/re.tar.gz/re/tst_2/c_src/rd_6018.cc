#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(atan2(e,c))*(atan2(e,d));
e=(pow(c,d))/(log10(c));
d=(fdim(a,d))+(acos(b));
c=(atan2(e,e))/(sqrt(d));
if(islessequal(c,d)){
b=fmax(a,c);
c=fmax(d,e);
}
else{
c=acos(b);
b=fmax(a,c);
e=fmax(a,e);
}
if(isless(c,b)){
a=tan(a);
b=pow(a,d);
}
else{
a=(asin(b))/(ceil(e));
e=sqrt(a);
}
}