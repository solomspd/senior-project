#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmax(e,b);
a=pow(e,f);
d=(ceil(d))+(atan2(b,c));
while(isgreaterequal(a,e)){
d=log(a);
b=fmax(f,f);
b=fmax(a,a);
}
if(isless(a,e)){
a=(exp(c))+(atan(e));
f=fdim(e,b);
}
else{
e=(sqrt(b))/(sqrt(c));
b=pow(e,f);
f=(floor(b))-(fmax(f,c));
f=(atan2(a,d))+(floor(d));
a=(fmax(c,d))+(atan2(e,f));
}
}