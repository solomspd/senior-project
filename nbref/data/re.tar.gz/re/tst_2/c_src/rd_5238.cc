#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=asin(c);
d=(ceil(b))*(sin(e));
d=ceil(b);
d=fmax(e,d);
e=(log10(a))/(acos(d));
while(isgreaterequal(g,c)){
a=(fdim(g,b))/(ceil(f));
e=sin(b);
a=(pow(b,d))-(exp(d));
g=(fmax(d,e))/(atan2(g,f));
}
while(islessgreater(d,c)){
g=log(b);
e=(fmax(a,c))*(cos(d));
a=(fmax(c,a))*(asin(a));
e=tan(d);
}
}