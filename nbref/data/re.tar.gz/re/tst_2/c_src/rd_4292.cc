#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(floor(e))*(pow(d,c));
b=(fmin(d,e))*(fdim(e,a));
e=(fdim(e,c))/(log(a));
d=(log10(d))-(fmin(d,a));
a=(acos(c))+(sin(e));
if(isless(d,c)){
e=fmin(d,d);
b=(pow(c,b))+(fdim(c,c));
b=(pow(c,e))-(fmin(a,d));
c=acos(d);
d=log10(a);
}
e=(pow(b,d))+(log10(d));
d=(atan2(e,a))/(fmin(a,d));
b=(cos(b))*(cos(d));
a=fdim(b,e);
c=fmin(b,d);
}