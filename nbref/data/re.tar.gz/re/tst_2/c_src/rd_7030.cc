#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=cos(b);
d=(pow(a,c))/(exp(d));
while(islessgreater(e,b)){
d=(ceil(e))+(sqrt(d));
d=(fmax(a,e))*(atan2(b,e));
b=sqrt(d);
e=(fmax(b,e))-(log(d));
c=sqrt(e);
}
if(isgreaterequal(b,d)){
e=(atan(c))+(exp(d));
b=(log(e))-(pow(a,d));
e=(fmax(d,c))*(acos(c));
a=fmin(c,c);
}
}