#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(asin(a))*(exp(e));
e=fmin(c,a);
b=(tan(b))*(atan2(a,e));
c=fdim(a,d);
b=(pow(d,e))-(atan2(e,e));
c=acos(c);
d=(log10(d))+(cos(e));
b=sqrt(a);
if(isgreaterequal(b,d)){
c=fmax(c,b);
a=(fdim(d,a))-(fdim(a,c));
b=(sqrt(b))/(exp(e));
a=fmin(a,e);
}
else{
e=fmin(b,d);
a=tan(e);
c=(atan2(e,c))-(ceil(b));
b=acos(b);
a=pow(a,d);
}
}