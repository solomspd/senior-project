#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=ceil(e);
d=(fdim(a,b))*(log10(e));
d=(fmax(e,a))/(pow(e,b));
d=pow(b,c);
c=(fdim(b,c))*(pow(a,e));
a=fdim(c,c);
c=log10(c);
}