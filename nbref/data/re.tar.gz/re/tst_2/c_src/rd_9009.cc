#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=(fmax(b,a))+(fmax(b,f));
e=fmin(d,g);
g=(tan(a))*(fmin(c,c));
a=(fmin(c,d))-(asin(c));
f=pow(e,e);
while(isless(f,c)){
g=fmin(c,e);
a=(fmin(a,b))/(atan2(a,a));
e=(fmax(c,d))+(cos(a));
d=(fdim(g,d))*(ceil(a));
b=(pow(b,f))+(sqrt(d));
}
if(islessgreater(d,b)){
g=(fdim(b,c))+(cos(d));
d=fdim(e,g);
}
else{
g=fmin(a,g);
g=pow(g,c);
}
}