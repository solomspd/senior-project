#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(fmin(b,h))*(fmax(f,d));
f=atan2(c,e);
h=cos(g);
if(isless(b,b)){
h=(fmin(g,a))-(exp(e));
a=(fdim(a,b))*(log(a));
b=(asin(f))*(tan(h));
h=(atan(f))-(fdim(f,f));
}
else{
e=pow(e,f);
c=(atan2(f,c))+(log10(h));
c=(atan(h))+(pow(a,b));
d=fmax(d,e);
}
g=(atan(b))-(sin(b));
a=sqrt(c);
b=(tan(f))-(tan(g));
f=(fdim(b,c))-(asin(g));
}