#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=asin(e);
d=atan2(e,a);
g=tan(f);
while(islessequal(b,a)){
a=(fmax(e,f))*(asin(c));
f=(asin(c))+(tan(g));
g=(asin(d))/(fmin(d,d));
e=log10(a);
f=fmax(d,h);
}
h=fmax(g,c);
f=log10(f);
c=(atan2(h,e))/(log10(a));
}