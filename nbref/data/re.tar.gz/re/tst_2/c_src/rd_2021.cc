#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=atan2(d,b);
c=tan(e);
b=(log(e))/(atan2(f,c));
b=(sin(d))/(pow(d,e));
f=(pow(a,e))*(log10(d));
c=(fmax(b,f))/(atan2(c,b));
a=(atan2(b,d))*(sqrt(d));
c=(tan(b))/(log10(d));
b=(tan(c))*(fmin(a,c));
while(islessgreater(d,b)){
d=(fdim(c,f))+(tan(d));
d=(cos(a))*(sqrt(c));
f=(exp(d))*(sin(a));
e=(atan2(a,e))+(log10(c));
c=fdim(e,b);
}
}