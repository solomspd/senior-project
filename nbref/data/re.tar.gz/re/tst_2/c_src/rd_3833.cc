#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(atan2(b,e))*(asin(b));
f=(fdim(a,f))/(fdim(e,f));
while(islessequal(b,a)){
a=atan2(d,d);
d=cos(a);
}
if(islessequal(e,d)){
e=fdim(c,d);
e=cos(a);
c=(fmax(c,d))+(fdim(b,f));
f=(fdim(e,f))+(sqrt(f));
c=(exp(a))*(sqrt(d));
}
}