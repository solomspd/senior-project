#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=atan2(f,d);
e=(fmin(b,a))+(pow(e,a));
e=(fmax(d,f))+(sin(e));
c=(fdim(e,f))-(acos(e));
f=fdim(b,e);
if(islessequal(c,e)){
c=(acos(e))/(asin(a));
d=(atan2(b,a))*(asin(c));
c=(exp(e))*(tan(e));
f=acos(d);
c=(pow(d,d))/(fmax(b,c));
}
else{
e=fmax(f,b);
e=fmin(b,a);
c=(fdim(b,f))-(atan2(d,f));
a=exp(b);
}
if(islessequal(f,c)){
d=pow(a,d);
d=(atan2(c,d))/(atan(d));
a=fdim(e,a);
d=sin(f);
}
else{
e=(atan(c))/(pow(c,c));
a=ceil(b);
a=pow(b,f);
c=atan(d);
}
}