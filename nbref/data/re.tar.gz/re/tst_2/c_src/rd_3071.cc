#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=(fdim(f,b))-(sin(b));
e=atan(f);
g=(fmin(c,b))/(cos(e));
b=(pow(c,c))+(ceil(c));
f=fmax(a,d);
f=(sqrt(f))*(exp(b));
f=cos(a);
d=fdim(c,b);
e=(fmax(f,f))/(fmax(f,g));
a=log10(f);
e=(ceil(c))-(fdim(c,c));
c=asin(b);
}