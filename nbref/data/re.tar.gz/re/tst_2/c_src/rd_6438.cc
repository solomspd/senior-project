#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=asin(e);
e=asin(a);
f=(atan2(f,d))/(pow(c,f));
f=(tan(a))+(tan(f));
if(islessequal(f,a)){
c=(acos(b))+(log(c));
a=fmax(c,a);
}
d=sin(d);
a=(log10(c))+(atan2(d,f));
a=sqrt(b);
c=cos(b);
b=asin(a);
}