#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fmax(d,a))*(fdim(b,d));
a=pow(c,b);
if(islessequal(e,b)){
c=asin(c);
d=asin(c);
a=fdim(a,e);
c=(log10(d))/(acos(e));
}
else{
a=log10(a);
d=(sin(e))*(fmax(a,c));
c=fmin(b,c);
c=pow(e,c);
}
if(islessgreater(e,b)){
b=pow(b,a);
d=atan2(b,c);
b=(ceil(a))+(ceil(e));
e=(sin(b))/(asin(c));
}
}