#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=log10(c);
e=fdim(a,a);
while(islessgreater(b,a)){
d=pow(b,b);
e=(log10(d))-(fdim(b,b));
c=(fdim(c,c))*(fdim(a,c));
d=(atan2(a,e))/(fmin(a,a));
a=acos(e);
}
while(isless(b,c)){
a=(atan2(d,c))*(acos(b));
a=atan2(b,a);
d=fmax(b,c);
}
}