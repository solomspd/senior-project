#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmin(b,c);
c=(atan2(a,a))*(sin(a));
while(isless(a,f)){
f=(floor(c))*(fdim(d,c));
e=(pow(d,d))/(atan2(b,d));
d=(fdim(a,b))-(acos(c));
}
if(isless(a,a)){
f=cos(a);
b=cos(a);
f=acos(b);
}
else{
d=(fdim(f,a))/(pow(f,b));
b=(pow(a,f))/(atan2(f,b));
d=cos(c);
a=fmin(e,f);
d=asin(c);
}
}