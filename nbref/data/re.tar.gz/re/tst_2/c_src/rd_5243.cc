#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(sin(b))+(log(a));
b=(fmin(c,a))/(exp(e));
f=tan(f);
a=(sin(e))/(atan2(c,d));
f=acos(b);
b=fmax(f,b);
a=floor(e);
f=(atan2(f,d))+(fmin(a,b));
}