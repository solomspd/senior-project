#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(pow(c,a))/(atan2(a,f));
c=(log10(f))-(pow(e,f));
e=(asin(g))+(log(d));
e=(atan2(c,e))-(sin(f));
d=atan2(b,f);
f=(log(a))+(fdim(e,g));
g=(pow(g,e))-(cos(a));
a=(fmax(a,e))-(sin(e));
c=fmin(g,b);
b=(fdim(b,f))-(fmax(f,d));
if(islessgreater(g,e)){
f=fdim(b,b);
f=(fdim(g,d))*(cos(b));
d=cos(e);
c=(fdim(b,d))/(atan2(c,g));
d=(sin(a))+(pow(c,f));
}
else{
c=(tan(e))*(fmax(f,c));
e=(ceil(f))*(fmin(e,g));
a=log10(e);
b=atan2(a,g);
d=(fmin(g,b))+(atan2(e,d));
}
}