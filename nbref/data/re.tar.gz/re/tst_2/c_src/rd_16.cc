#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fmax(c,e))-(fdim(a,b));
a=fdim(a,d);
d=atan2(c,a);
b=(fmax(c,c))*(exp(b));
if(isless(b,c)){
e=sin(a);
b=atan(c);
b=(atan(b))*(pow(c,b));
b=log(e);
}
else{
d=exp(e);
a=fmax(d,b);
c=(atan2(a,c))-(log(c));
e=(pow(a,c))+(pow(d,b));
}
b=(fdim(d,c))+(fmax(d,c));
a=fdim(e,a);
b=(exp(e))*(log(c));
b=(fmin(e,a))/(atan2(b,c));
e=fdim(b,c);
}