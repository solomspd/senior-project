#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
h=(atan(d))*(tan(b));
c=asin(h);
f=acos(a);
if(isgreaterequal(d,c)){
g=(log10(g))-(acos(e));
h=(cos(f))+(fmax(c,g));
d=asin(c);
e=(fmax(h,d))+(pow(a,f));
}
else{
e=acos(f);
c=(asin(b))+(tan(d));
}
e=(sin(f))/(fmin(h,e));
a=log(a);
}