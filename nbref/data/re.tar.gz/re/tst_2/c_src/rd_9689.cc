#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=fdim(c,b);
d=(fmin(d,b))/(tan(a));
d=pow(b,b);
c=(sin(c))+(atan2(b,d));
c=fmax(a,c);
d=(log(b))-(log(a));
while(islessequal(b,a)){
c=(pow(c,e))/(sin(d));
e=(atan2(c,d))-(acos(b));
c=fdim(c,c);
a=(fdim(d,e))/(acos(b));
d=(asin(b))-(fdim(c,c));
}
}