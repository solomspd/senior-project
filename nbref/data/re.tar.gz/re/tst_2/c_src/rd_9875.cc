#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(acos(e))+(sin(b));
a=(pow(d,a))/(atan(b));
d=(fmax(d,b))-(fdim(d,d));
b=(fdim(a,c))-(atan2(c,e));
e=(fmax(b,e))+(fdim(a,c));
e=floor(c);
c=(acos(e))/(sqrt(d));
e=sin(e);
e=(atan2(e,c))*(fmax(a,d));
}