#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=pow(e,b);
b=(fmax(c,c))*(fmin(d,e));
b=pow(b,b);
b=pow(d,d);
while(isgreaterequal(e,d)){
c=fdim(a,a);
b=(fdim(c,b))*(pow(a,a));
d=(log10(b))+(pow(b,c));
}
a=atan(e);
d=fdim(e,a);
c=fdim(e,a);
d=(acos(d))*(fmin(e,b));
}