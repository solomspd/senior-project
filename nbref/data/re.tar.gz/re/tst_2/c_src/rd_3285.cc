#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(pow(d,a))*(atan2(g,d));
a=fmin(b,f);
c=(fmax(g,a))/(tan(d));
a=(sqrt(c))+(atan2(b,g));
a=(cos(a))/(pow(e,g));
if(islessgreater(c,c)){
c=(atan2(e,c))/(fmin(a,b));
d=(pow(c,g))+(pow(b,e));
}
if(isless(a,b)){
f=fdim(f,h);
d=fmin(f,c);
g=pow(g,f);
}
}