#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=fmin(c,d);
d=acos(h);
c=(sqrt(f))+(pow(c,d));
h=(fdim(b,g))*(fmax(d,f));
h=floor(e);
g=(ceil(d))+(pow(d,e));
while(isless(e,h)){
e=sqrt(f);
d=fmin(g,g);
f=floor(c);
h=tan(g);
c=exp(h);
}
}