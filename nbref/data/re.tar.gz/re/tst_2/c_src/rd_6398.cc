#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=atan(c);
c=cos(a);
while(isless(a,e)){
d=(ceil(e))+(atan(d));
e=(fmin(e,c))*(atan(d));
e=(fdim(c,d))/(sqrt(c));
}
if(isless(e,a)){
a=(fmax(d,c))+(atan2(c,b));
b=fmin(e,b);
c=(log10(c))+(tan(e));
e=ceil(c);
}
else{
e=fdim(b,c);
d=ceil(e);
a=(pow(e,a))*(ceil(b));
}
}