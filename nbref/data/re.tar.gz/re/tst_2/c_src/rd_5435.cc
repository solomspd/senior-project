#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmax(b,e))/(cos(c));
e=atan2(e,e);
a=(asin(e))+(cos(b));
b=atan2(d,a);
b=(pow(b,e))-(sin(e));
while(islessgreater(a,e)){
a=fmin(b,d);
e=(fdim(c,a))/(log(c));
b=(fmin(d,c))*(ceil(a));
d=(cos(a))*(fdim(e,d));
d=(cos(c))/(floor(e));
}
a=fmax(c,c);
c=(fdim(a,c))-(fdim(a,e));
a=(floor(e))*(pow(e,d));
c=pow(a,a);
e=asin(c);
}