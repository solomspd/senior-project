#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(cos(b))-(cos(e));
a=fdim(e,e);
e=sin(a);
d=log10(b);
e=floor(c);
if(islessequal(a,b)){
b=acos(d);
b=fmax(a,d);
e=(acos(d))-(atan2(d,b));
c=(fdim(d,a))/(atan2(e,c));
a=floor(e);
}
else{
c=(log10(d))-(fmax(c,b));
d=log10(d);
b=(fmax(c,c))-(asin(e));
c=(ceil(c))+(fdim(c,b));
a=cos(e);
}
if(islessgreater(b,b)){
e=fmax(e,d);
a=(sin(e))/(fdim(a,b));
b=atan(b);
d=atan2(e,c);
}
}