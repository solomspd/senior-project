#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=tan(a);
b=fmin(h,c);
f=exp(a);
while(isless(d,c)){
g=fdim(d,a);
c=cos(c);
f=exp(f);
}
while(isless(b,f)){
d=sin(b);
b=(atan2(b,h))/(sin(g));
h=tan(e);
d=(log(e))-(log(g));
}
}