#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(atan2(d,b))/(ceil(b));
f=(fmin(f,b))-(tan(c));
f=fmax(b,b);
c=(floor(a))+(fdim(c,f));
a=fdim(a,a);
g=(pow(f,c))/(pow(a,g));
b=(pow(a,a))*(cos(g));
c=atan2(f,g);
f=(sqrt(g))/(fmax(g,c));
d=(fmin(g,d))+(sin(c));
d=log(f);
}