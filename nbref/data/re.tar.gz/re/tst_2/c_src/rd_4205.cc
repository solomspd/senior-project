#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(fmin(b,g))/(log10(d));
f=acos(d);
f=acos(g);
e=cos(d);
g=log10(f);
a=(tan(e))+(acos(c));
b=(fmin(g,f))/(log(g));
a=fdim(e,b);
a=(sin(d))/(fdim(c,a));
}