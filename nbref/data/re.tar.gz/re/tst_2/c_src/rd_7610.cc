#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(fdim(b,a))*(fdim(a,a));
a=(pow(d,d))/(exp(e));
e=fmin(d,d);
if(islessgreater(d,e)){
e=(fdim(a,a))-(fdim(c,a));
c=(fmax(d,b))/(fmax(b,b));
a=(pow(c,d))-(ceil(a));
d=(fmin(c,d))/(asin(a));
d=(ceil(a))+(pow(a,e));
}
b=(fmax(d,e))/(cos(d));
d=(fmax(e,d))*(fmin(b,c));
a=fmax(e,b);
}