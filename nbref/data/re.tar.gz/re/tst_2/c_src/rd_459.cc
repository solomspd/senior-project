#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(floor(b))+(pow(b,d));
c=atan2(b,e);
b=exp(b);
while(islessequal(d,a)){
a=atan2(b,e);
e=asin(e);
d=(sin(c))/(log10(d));
e=sin(a);
}
while(isless(c,c)){
e=fmin(c,a);
b=atan2(c,d);
a=pow(d,d);
d=atan2(d,a);
}
}