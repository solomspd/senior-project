#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=exp(f);
a=fmax(e,e);
c=ceil(g);
c=asin(c);
b=(log(e))/(atan2(a,b));
a=fmax(f,c);
f=(fmax(a,a))+(exp(b));
e=(pow(b,b))/(fmax(c,b));
e=fmin(c,e);
while(isless(d,a)){
d=fdim(a,g);
a=(fmax(a,d))+(atan2(b,b));
c=(fmin(g,f))/(tan(f));
a=(fmin(e,a))/(exp(c));
}
}