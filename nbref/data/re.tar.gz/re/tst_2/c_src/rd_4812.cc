#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
a=(fmax(b,g))+(log(f));
c=log(a);
g=atan(h);
d=log10(a);
while(islessgreater(d,f)){
g=asin(a);
h=(log10(b))/(fmin(g,g));
g=fmin(g,a);
}
f=cos(b);
h=(acos(b))/(fmax(c,c));
a=(sin(h))+(fdim(a,g));
f=fdim(g,d);
b=tan(d);
}