#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fmax(a,c);
e=tan(d);
a=(atan2(c,b))-(fmax(d,b));
b=(fdim(a,d))-(floor(a));
b=pow(d,c);
if(islessgreater(b,e)){
e=(asin(d))/(log(e));
c=asin(e);
a=(fmin(e,c))/(fmin(d,e));
}
else{
d=fdim(e,c);
c=pow(b,a);
}
while(isgreaterequal(e,a)){
a=pow(b,a);
d=atan2(a,a);
}
}