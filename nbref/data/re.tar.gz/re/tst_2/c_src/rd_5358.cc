#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=fdim(b,c);
a=(pow(e,a))+(tan(e));
d=(cos(e))*(atan2(d,e));
a=cos(b);
if(isgreaterequal(e,b)){
b=(pow(a,d))/(fdim(b,d));
d=(log(c))*(fdim(d,d));
c=log10(e);
c=log10(c);
}
while(islessgreater(c,a)){
e=(fdim(e,a))*(exp(b));
c=(atan2(a,e))*(exp(c));
c=tan(a);
d=atan2(b,d);
b=atan(e);
}
}