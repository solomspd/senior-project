#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=acos(e);
c=fmax(c,d);
c=(fmax(c,b))/(fmax(b,d));
c=(cos(d))*(fmax(a,b));
a=(pow(e,c))*(asin(e));
d=cos(b);
d=atan2(d,a);
if(islessequal(a,b)){
c=(atan2(d,c))*(acos(d));
d=(fmin(b,b))/(ceil(b));
a=(fmin(c,a))/(log(c));
d=log10(c);
e=sqrt(a);
}
else{
b=(fdim(d,d))+(fmax(d,c));
a=(fdim(a,a))-(log10(d));
}
}