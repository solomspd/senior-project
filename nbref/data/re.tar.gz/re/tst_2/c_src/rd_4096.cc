#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
a=(fmin(g,b))/(atan(e));
f=(atan(e))*(pow(f,e));
b=log10(b);
g=(fmax(g,b))-(floor(e));
d=ceil(e);
while(islessgreater(b,e)){
c=atan2(f,a);
b=fdim(b,e);
}
if(isless(e,d)){
a=(pow(d,e))-(pow(f,d));
e=atan(a);
b=fmax(e,a);
d=asin(g);
c=sqrt(d);
}
else{
f=pow(c,d);
g=tan(g);
f=(atan2(f,b))*(fdim(c,c));
f=sqrt(b);
}
}