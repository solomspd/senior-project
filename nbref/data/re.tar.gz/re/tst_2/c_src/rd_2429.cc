#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=atan2(e,a);
c=(ceil(d))*(cos(f));
c=pow(e,g);
if(isless(e,b)){
a=(fmax(a,e))*(pow(a,a));
d=(sqrt(a))+(atan2(f,a));
f=log(a);
d=(pow(e,c))-(cos(g));
b=cos(b);
}
f=ceil(a);
g=(atan2(d,g))*(log(c));
}