#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=ceil(e);
b=sin(e);
while(islessgreater(a,c)){
c=acos(c);
c=fmax(f,e);
}
while(islessequal(f,c)){
f=(atan2(g,b))*(tan(g));
c=fmax(c,f);
g=(floor(c))+(atan2(f,a));
a=floor(c);
}
}