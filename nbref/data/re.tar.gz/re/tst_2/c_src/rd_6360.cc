#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(fmin(f,b))/(log(c));
d=atan2(f,a);
while(isless(b,e)){
d=(fmin(e,e))/(log10(a));
e=sqrt(b);
f=log(a);
}
while(isgreaterequal(e,b)){
f=(pow(b,c))-(floor(d));
d=fmin(a,e);
b=(sin(c))*(pow(f,b));
a=(pow(f,a))*(atan2(f,a));
b=(fmin(c,e))-(fmax(d,c));
}
}