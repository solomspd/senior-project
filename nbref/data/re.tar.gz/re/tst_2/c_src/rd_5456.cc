#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=(pow(c,b))/(ceil(d));
e=(ceil(e))+(fmin(a,a));
d=log(d);
b=fdim(a,a);
b=(pow(a,a))-(atan2(b,b));
if(isgreaterequal(a,a)){
a=(fdim(d,c))/(log(e));
d=ceil(c);
a=(log10(b))+(ceil(b));
a=atan(b);
}
if(isgreaterequal(c,c)){
e=(fmin(b,b))-(atan2(a,e));
d=(fmin(a,d))-(exp(c));
a=(log10(a))+(atan2(a,b));
e=(sin(e))+(fmax(b,c));
}
else{
a=tan(b);
c=exp(e);
a=log(b);
a=(fdim(d,a))+(pow(d,b));
a=fmax(c,a);
}
}