#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=cos(c);
c=fmin(b,g);
d=ceil(f);
c=(exp(e))+(fdim(e,a));
b=(sin(d))/(pow(g,f));
a=(fdim(b,c))/(exp(b));
b=sqrt(c);
g=(pow(f,d))*(atan(a));
c=(fdim(e,g))+(asin(d));
a=(fmax(c,g))+(asin(g));
g=log(e);
b=(exp(b))+(fdim(d,c));
}