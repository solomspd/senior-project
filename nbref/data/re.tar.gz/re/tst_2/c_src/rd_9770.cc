#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=(fdim(e,g))*(fdim(b,h));
h=(fmin(e,d))*(exp(e));
a=atan2(a,e);
b=(fmax(g,e))-(exp(g));
c=(sin(f))-(fdim(a,e));
c=log(h);
e=cos(f);
g=(acos(h))+(atan(a));
b=(acos(e))+(fmin(a,c));
c=(exp(d))*(tan(b));
}