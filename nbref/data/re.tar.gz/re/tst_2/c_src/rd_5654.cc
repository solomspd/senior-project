#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=cos(a);
e=(fdim(f,c))/(pow(a,b));
if(isgreaterequal(e,f)){
c=atan2(c,c);
c=(fdim(a,a))-(floor(c));
b=fmax(c,b);
}
else{
a=pow(f,b);
b=log10(f);
c=(pow(d,b))-(fdim(c,f));
}
if(islessequal(a,f)){
a=log(c);
e=atan(e);
e=ceil(e);
a=fmax(d,d);
f=log10(c);
}
}