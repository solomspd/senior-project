#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
b=sin(a);
g=asin(d);
a=(log10(a))*(fmin(d,e));
f=floor(e);
b=(pow(c,d))*(fmax(g,g));
if(isgreaterequal(b,d)){
f=(pow(e,a))*(fmax(c,a));
g=(fmin(b,b))+(atan2(d,a));
c=(fmin(g,g))-(atan2(e,d));
b=fmax(d,d);
b=(cos(g))+(pow(d,f));
}
else{
e=cos(a);
a=asin(c);
c=log(a);
a=atan(c);
}
b=atan2(f,g);
c=(cos(c))/(atan2(f,a));
g=(ceil(f))-(asin(e));
d=pow(g,c);
}