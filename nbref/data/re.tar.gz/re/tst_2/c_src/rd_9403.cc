#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(ceil(f))*(fdim(b,g));
b=(fdim(d,f))/(log10(c));
e=(pow(h,f))/(floor(a));
if(isless(d,b)){
a=pow(e,a);
e=(sqrt(h))/(floor(g));
}
h=(fdim(h,c))-(pow(c,h));
b=(atan(b))*(tan(d));
f=(cos(a))*(sin(d));
}