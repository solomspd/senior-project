#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=exp(c);
e=fdim(b,a);
g=(fdim(g,f))/(pow(d,d));
d=(fmax(e,f))+(atan(c));
d=(fdim(d,f))*(atan2(c,b));
if(islessgreater(f,b)){
b=(fdim(e,d))+(atan2(a,d));
f=(pow(a,e))*(pow(e,c));
}
else{
d=log10(d);
g=(fdim(f,a))/(fmax(b,c));
d=cos(a);
c=(pow(g,e))-(floor(c));
e=atan2(b,e);
}
}