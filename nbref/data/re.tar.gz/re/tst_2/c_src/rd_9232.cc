#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(fmax(b,c))*(log10(d));
a=(atan2(d,a))+(fmax(e,e));
e=atan2(a,a);
c=acos(d);
if(isless(a,c)){
e=(floor(c))-(fmin(e,b));
b=(fmax(d,a))-(fdim(e,d));
e=(cos(b))*(pow(b,d));
c=(atan2(e,c))*(fdim(e,b));
}
else{
b=(pow(d,c))+(atan2(d,e));
d=atan(b);
a=(cos(a))+(fmax(e,c));
d=(asin(d))+(sqrt(d));
b=(exp(e))+(atan2(d,a));
}
if(islessgreater(a,d)){
d=(log(a))/(log(c));
a=tan(a);
}
else{
e=pow(d,b);
b=(atan2(c,d))+(log(a));
e=sqrt(b);
}
}