#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=(cos(b))/(atan(c));
a=(exp(e))*(atan2(c,f));
d=(log(e))*(fmax(b,f));
b=(pow(e,c))*(sqrt(b));
f=sqrt(c);
if(isless(a,a)){
e=(fmin(e,f))-(floor(a));
b=ceil(b);
g=(floor(f))/(sqrt(d));
g=floor(c);
g=(fdim(g,g))/(asin(c));
}
else{
c=tan(f);
a=(atan2(c,a))/(fmax(d,f));
d=(ceil(c))-(exp(a));
}
if(isless(d,c)){
b=fmin(e,b);
c=floor(c);
}
}