#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(pow(d,c))+(fdim(d,c));
b=(log(a))*(pow(b,a));
d=(floor(e))-(acos(b));
d=(fmax(b,e))-(fmax(d,d));
d=acos(e);
while(islessequal(c,a)){
c=pow(d,e);
d=pow(b,b);
b=(exp(a))/(cos(d));
e=(floor(c))+(fmin(a,d));
a=fmax(d,c);
}
while(islessequal(b,d)){
c=(sin(b))-(fdim(c,e));
c=(fmin(e,a))*(log10(e));
d=(fdim(a,d))*(ceil(e));
e=sqrt(a);
a=fmax(e,b);
}
}