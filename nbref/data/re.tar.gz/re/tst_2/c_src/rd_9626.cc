#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(log10(a))/(sqrt(d));
a=ceil(e);
d=floor(f);
e=floor(d);
while(isless(c,g)){
g=pow(a,h);
a=fdim(d,a);
h=ceil(h);
g=log(e);
}
}