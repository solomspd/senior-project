#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
e=(atan(g))/(asin(b));
f=fmax(c,f);
e=(log10(c))-(fdim(e,g));
d=fdim(g,f);
g=cos(h);
g=pow(f,e);
h=(pow(g,b))*(fmax(g,c));
f=(sqrt(c))*(atan2(e,h));
}