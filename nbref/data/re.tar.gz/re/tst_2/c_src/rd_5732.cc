#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=log10(a);
d=exp(d);
c=(pow(c,b))/(acos(e));
d=floor(d);
while(isless(b,b)){
b=(cos(e))*(log10(d));
a=(fmin(c,a))*(fmax(e,c));
e=(atan(d))-(atan2(e,e));
a=tan(b);
b=fmin(d,a);
}
while(islessequal(b,d)){
c=fmax(d,a);
d=(fmax(b,d))-(tan(c));
a=(pow(d,a))-(fmin(e,c));
d=(tan(d))+(acos(a));
}
}