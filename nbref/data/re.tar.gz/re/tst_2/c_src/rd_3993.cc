#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(acos(c))/(fmin(d,a));
e=tan(e);
e=atan2(b,b);
d=pow(c,a);
e=(fmin(e,d))-(fmax(e,d));
b=sin(e);
a=pow(c,b);
c=sin(e);
d=asin(e);
while(islessgreater(b,e)){
e=(atan(d))-(pow(c,d));
d=fmax(b,e);
a=(log10(a))-(log(e));
c=(sin(b))*(fmax(a,b));
a=(log10(e))+(fmin(b,c));
}
}