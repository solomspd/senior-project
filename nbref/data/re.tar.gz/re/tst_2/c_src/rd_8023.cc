#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(atan2(c,d))+(fdim(e,a));
c=(tan(d))*(atan2(c,c));
c=sin(e);
a=fdim(d,e);
c=fmin(d,e);
while(islessequal(e,a)){
e=(sin(b))*(atan2(c,c));
e=pow(e,d);
}
d=floor(c);
d=log(c);
a=(tan(c))*(log10(b));
e=(fmax(c,a))+(ceil(b));
c=(atan(b))+(floor(c));
}