#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
e=sqrt(d);
f=(pow(b,d))/(floor(c));
b=fdim(b,f);
a=sqrt(g);
f=log(e);
e=fmin(g,b);
a=(floor(d))*(sin(a));
g=(log(g))+(fdim(c,f));
e=pow(a,b);
if(islessgreater(e,f)){
a=(fmax(f,f))+(fmin(c,f));
c=fmax(f,e);
}
}