#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=(asin(e))/(fmax(g,b));
e=(fmax(b,a))+(pow(g,c));
f=exp(e);
e=ceil(d);
f=ceil(e);
d=fmax(g,g);
b=(pow(g,a))*(fdim(d,g));
d=fmax(d,g);
d=acos(f);
g=(log(b))/(pow(b,e));
b=pow(f,e);
}