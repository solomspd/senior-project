#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=exp(a);
d=(log(f))*(pow(a,d));
c=(pow(e,b))/(atan(c));
f=fmax(f,c);
b=atan2(d,e);
d=(exp(a))*(fmax(f,a));
d=log(c);
while(isless(e,d)){
a=(atan2(e,d))-(floor(e));
b=(pow(e,b))+(exp(f));
}
}