#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(fmax(f,a))/(sin(d));
d=log10(b);
g=(tan(a))/(fmin(c,f));
g=(cos(c))*(pow(a,a));
c=acos(c);
if(islessgreater(c,g)){
e=pow(g,f);
a=(floor(f))/(atan2(a,b));
}
f=(sin(b))/(floor(c));
f=fmax(c,b);
b=(exp(g))+(acos(c));
e=(log(e))/(floor(f));
b=pow(c,g);
}