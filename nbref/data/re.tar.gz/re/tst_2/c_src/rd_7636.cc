#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=fmax(b,d);
d=fmin(a,e);
b=atan2(b,a);
e=log(d);
a=(atan2(b,b))-(fmax(a,e));
if(isgreaterequal(c,d)){
e=acos(a);
b=(atan2(b,c))*(fmax(e,b));
}
else{
e=log10(c);
c=(exp(a))/(sqrt(a));
c=(fdim(a,d))*(atan2(d,a));
c=fmax(b,b);
d=log10(e);
}
d=atan2(e,b);
e=(fmax(d,e))*(floor(d));
b=tan(c);
d=cos(a);
b=(tan(d))-(atan2(b,b));
}