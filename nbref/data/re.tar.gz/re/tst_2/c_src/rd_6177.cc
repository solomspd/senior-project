#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmin(f,e);
c=atan2(d,b);
if(isless(e,d)){
d=(fdim(a,c))+(tan(d));
b=(log(e))*(fmin(b,f));
e=fmax(b,f);
}
else{
b=(atan2(a,c))/(fmin(c,f));
a=(floor(d))/(fdim(f,c));
f=pow(e,c);
}
d=ceil(f);
f=pow(f,f);
c=atan(c);
f=(fdim(f,d))-(log10(c));
f=fmin(c,c);
}