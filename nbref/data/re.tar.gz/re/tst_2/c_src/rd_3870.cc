#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
c=(sqrt(c))+(tan(b));
h=sin(g);
while(isless(e,d)){
c=(log10(a))-(cos(h));
h=(pow(e,d))*(exp(b));
}
if(islessequal(b,e)){
e=(fdim(a,h))+(pow(g,d));
d=asin(a);
}
else{
g=(tan(e))-(pow(d,h));
f=(pow(h,a))/(atan2(f,c));
}
}