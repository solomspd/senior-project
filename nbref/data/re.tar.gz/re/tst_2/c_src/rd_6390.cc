#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(floor(c))+(asin(b));
e=(fmax(b,c))-(atan2(e,b));
c=(fmax(a,b))*(floor(e));
d=(sin(a))-(fmax(c,c));
c=(fmax(a,b))/(ceil(e));
if(isless(d,e)){
d=(pow(d,e))+(fmax(e,b));
e=cos(c);
}
if(islessequal(c,b)){
e=(fdim(b,e))+(pow(a,d));
e=fdim(e,a);
e=(fdim(d,d))*(ceil(b));
e=atan2(c,c);
a=fmax(b,a);
}
}