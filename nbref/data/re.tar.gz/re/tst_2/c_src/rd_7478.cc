#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=log10(c);
f=fmax(a,f);
f=atan2(d,e);
b=(atan2(e,d))*(fmax(c,b));
e=(fdim(f,c))*(acos(a));
c=(exp(a))*(sin(b));
f=(sin(a))/(pow(c,a));
if(isless(b,a)){
a=pow(f,e);
d=(cos(c))+(pow(a,a));
d=(pow(f,d))/(cos(b));
}
else{
e=asin(c);
b=(atan(f))*(sin(a));
b=(atan(f))/(log(d));
}
}