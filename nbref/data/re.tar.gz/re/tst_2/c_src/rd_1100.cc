#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=exp(a);
b=(exp(f))-(log10(a));
c=fmax(a,a);
e=acos(a);
if(islessequal(c,c)){
a=(floor(g))/(fmax(c,b));
e=(fmax(d,g))*(pow(c,a));
e=pow(d,d);
}
while(isless(f,d)){
e=(fmin(c,f))/(floor(g));
f=(fdim(a,c))+(acos(c));
f=(exp(e))+(sqrt(d));
e=(fdim(f,f))-(fmin(f,e));
a=pow(d,b);
}
}