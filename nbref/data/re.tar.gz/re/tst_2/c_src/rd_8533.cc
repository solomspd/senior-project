#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=atan2(c,e);
d=(pow(f,f))*(log(b));
c=fmin(d,d);
d=(pow(b,e))*(floor(e));
d=log(b);
d=fmax(d,b);
}