#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=pow(c,d);
e=(asin(d))+(exp(d));
if(islessequal(e,b)){
b=floor(e);
a=(atan(c))+(fmin(c,e));
d=pow(b,b);
b=(fdim(c,c))+(pow(a,a));
}
a=(sqrt(d))-(fmin(d,d));
b=(fdim(a,e))+(atan(e));
c=(log10(e))*(sqrt(b));
}