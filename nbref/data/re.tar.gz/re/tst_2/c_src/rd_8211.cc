#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(fmax(d,c))/(fmax(e,b));
c=(cos(b))+(sin(a));
f=tan(f);
f=(fdim(f,b))*(pow(d,d));
c=(fmin(c,a))-(fdim(c,d));
if(isless(c,b)){
a=fdim(f,c);
a=(fmin(b,a))*(fmax(f,a));
e=fdim(b,e);
f=atan(e);
}
a=(fmax(a,e))-(fmax(d,e));
a=ceil(b);
f=(exp(b))+(pow(f,d));
b=sqrt(b);
e=pow(d,b);
}