#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=atan2(b,e);
b=(fmin(a,a))-(tan(c));
while(islessgreater(d,e)){
c=(fmax(e,a))+(ceil(b));
d=acos(b);
e=(log10(b))*(floor(d));
c=(fdim(a,a))+(log10(b));
b=(atan(e))-(pow(d,e));
}
if(islessgreater(d,b)){
b=pow(e,d);
a=sqrt(c);
b=(log10(c))-(fmin(b,a));
}
}