#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
e=(tan(c))*(atan2(b,a));
b=fdim(a,e);
f=(pow(f,e))/(fmax(c,b));
e=atan(b);
c=fmax(a,d);
b=(sin(c))/(log(a));
b=(log10(e))/(fdim(a,e));
f=pow(a,f);
d=(acos(e))-(fmax(e,f));
if(islessequal(d,e)){
a=(atan2(f,b))-(atan(d));
e=(fmin(f,b))/(fmax(e,e));
f=(fmax(f,a))/(fdim(e,e));
b=(fmin(f,e))+(floor(a));
f=(fmax(e,f))/(floor(a));
}
}