#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(atan2(c,b))+(floor(a));
g=log(d);
a=fdim(a,b);
a=fmax(g,a);
b=(fmin(c,e))+(sin(e));
b=floor(e);
a=(tan(f))-(pow(b,f));
b=(exp(c))-(atan2(f,e));
c=(log(a))/(sqrt(e));
b=fmin(c,g);
d=(fdim(f,d))-(atan2(d,f));
g=fmax(c,e);
}