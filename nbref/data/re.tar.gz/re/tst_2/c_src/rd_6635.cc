#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=(pow(c,e))/(ceil(b));
a=(cos(b))*(exp(e));
b=cos(b);
while(islessgreater(a,e)){
e=(acos(b))*(fdim(e,b));
d=(log(c))/(asin(a));
b=(atan2(a,e))-(fmax(e,e));
d=(fdim(b,e))*(sin(b));
}
while(islessgreater(c,a)){
d=fmax(d,b);
a=(log(a))/(cos(b));
a=(ceil(e))/(pow(b,e));
c=pow(a,d);
e=sin(e);
}
}