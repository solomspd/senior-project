#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
g=tan(b);
h=(atan2(f,c))+(fmin(h,f));
f=(atan(e))-(log10(h));
if(islessequal(f,f)){
a=(sqrt(f))/(atan2(d,g));
f=floor(g);
d=(tan(e))/(sin(d));
a=(sqrt(b))+(fdim(e,c));
b=tan(g);
}
else{
h=tan(d);
b=fmax(e,d);
c=atan2(b,h);
d=(fdim(c,f))*(fdim(g,b));
}
if(isless(h,b)){
e=(tan(b))-(fmax(c,g));
a=(fmax(d,d))-(asin(f));
e=(tan(h))-(atan2(b,a));
d=exp(f);
b=fmin(c,g);
}
else{
a=(log(g))+(tan(c));
c=(fmax(f,d))*(fmax(b,a));
a=(pow(d,a))/(fmin(h,d));
f=atan2(h,c);
e=sqrt(b);
}
}