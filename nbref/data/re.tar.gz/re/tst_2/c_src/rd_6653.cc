#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=pow(c,d);
d=pow(e,b);
a=fmin(b,e);
c=(fdim(e,a))+(fmax(c,d));
d=atan(b);
f=sin(c);
e=asin(d);
while(islessequal(e,b)){
e=fmax(a,c);
e=asin(f);
b=(asin(a))-(pow(d,f));
a=atan2(f,a);
d=tan(d);
}
}