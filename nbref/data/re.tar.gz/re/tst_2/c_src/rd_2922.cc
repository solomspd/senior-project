#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=fdim(c,b);
e=(fmin(c,b))*(fdim(a,a));
c=(pow(a,d))-(asin(c));
c=fmin(d,b);
e=fmin(e,a);
b=(fmax(d,b))-(fmin(c,d));
e=log(b);
e=(fdim(c,e))/(fmax(c,a));
e=(atan2(b,d))/(fmax(a,a));
c=(fdim(c,c))/(sin(b));
c=tan(d);
a=(fmin(c,a))-(fdim(d,e));
c=(fdim(c,e))/(pow(d,b));
}