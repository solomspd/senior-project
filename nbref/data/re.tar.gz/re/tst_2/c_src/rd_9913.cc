#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(fdim(a,a))/(fmin(b,a));
a=(log(c))*(cos(a));
b=fmax(b,a);
e=log10(d);
a=atan(b);
if(islessequal(a,c)){
d=sin(b);
e=atan2(e,d);
b=(pow(a,c))/(ceil(c));
e=(pow(b,c))+(cos(a));
}
else{
e=(tan(b))+(pow(e,a));
b=cos(e);
}
a=fdim(b,b);
c=fdim(e,e);
e=atan(a);
}