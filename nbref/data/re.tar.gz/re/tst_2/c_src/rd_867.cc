#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=atan(b);
c=(fdim(d,d))/(sqrt(d));
b=(log10(a))/(fdim(c,e));
if(isgreaterequal(c,a)){
c=cos(d);
d=fdim(b,e);
}
c=(fmin(b,a))/(log(b));
c=log(c);
d=fmin(e,e);
}