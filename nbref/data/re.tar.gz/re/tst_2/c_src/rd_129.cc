#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(log10(f))+(fmax(f,b));
b=(pow(b,c))+(log(e));
d=fdim(f,c);
if(islessequal(e,d)){
e=(exp(a))-(log10(e));
c=(floor(a))*(log10(a));
c=fmax(b,d);
}
else{
f=(floor(b))*(fdim(a,d));
f=fmin(d,c);
}
a=(ceil(b))*(ceil(b));
c=(ceil(d))-(log10(b));
b=fmin(d,d);
}