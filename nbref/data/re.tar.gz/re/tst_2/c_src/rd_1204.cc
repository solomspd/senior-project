#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fdim(b,c);
c=fmin(e,c);
while(isgreaterequal(d,d)){
c=fmax(c,d);
c=(fmin(d,a))+(acos(c));
b=(fmax(c,b))+(fmax(e,d));
}
while(islessgreater(d,e)){
e=(fmax(b,a))*(asin(b));
a=fmax(c,e);
b=(fdim(a,c))*(fmin(e,b));
c=(pow(c,a))+(asin(c));
}
}