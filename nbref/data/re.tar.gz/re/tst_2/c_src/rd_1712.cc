#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=cos(c);
a=sqrt(b);
f=(fdim(g,d))+(pow(c,g));
b=tan(f);
e=ceil(c);
if(isless(b,g)){
a=atan(c);
g=(fdim(b,d))-(log(f));
}
else{
a=(sqrt(b))-(pow(b,c));
g=atan(e);
d=asin(a);
f=fmax(f,a);
e=(log10(a))*(fdim(d,f));
}
f=log10(e);
g=fdim(a,g);
b=(fdim(e,a))/(fdim(d,a));
b=pow(c,f);
}