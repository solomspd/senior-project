#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=pow(e,d);
e=acos(e);
b=(fmin(a,a))/(tan(d));
while(isless(c,b)){
b=acos(a);
d=(log10(d))*(cos(a));
a=(asin(b))+(pow(e,e));
e=asin(e);
}
if(islessgreater(e,c)){
b=fdim(d,e);
b=(tan(b))*(fmin(d,a));
a=floor(a);
d=atan2(a,c);
a=(fdim(a,d))/(floor(c));
}
else{
c=(atan2(d,a))*(fmin(a,c));
e=(log(b))/(exp(c));
}
}