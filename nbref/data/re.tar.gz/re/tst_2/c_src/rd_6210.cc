#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(fdim(c,h))*(fmax(g,f));
d=(tan(d))+(asin(a));
h=fmax(e,e);
d=exp(f);
g=(fmax(c,f))/(tan(b));
d=atan(c);
a=sin(c);
f=(fmin(f,g))+(atan2(b,c));
b=exp(d);
}