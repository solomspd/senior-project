#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=fdim(b,g);
b=sin(d);
g=(floor(f))+(fdim(d,a));
a=fdim(e,c);
f=(atan2(g,a))+(fmax(b,e));
g=(fmin(c,e))-(fmax(b,a));
f=(acos(f))/(fmin(c,g));
if(isgreaterequal(a,b)){
f=cos(g);
d=atan2(b,e);
}
else{
d=log(e);
c=asin(d);
}
}