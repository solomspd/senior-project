#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=fmax(f,d);
c=(exp(a))+(pow(a,d));
a=floor(c);
while(isgreaterequal(f,f)){
b=(sqrt(c))*(acos(a));
b=fmin(a,d);
}
while(islessequal(b,f)){
c=(pow(e,c))-(pow(d,a));
f=asin(c);
e=(exp(b))-(fmax(d,f));
f=fdim(d,b);
b=acos(d);
}
}