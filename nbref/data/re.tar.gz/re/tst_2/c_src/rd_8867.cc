#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(pow(b,a))-(atan(a));
a=(pow(a,a))+(ceil(d));
a=cos(e);
if(isless(a,c)){
a=atan2(b,e);
e=(fdim(d,a))*(pow(b,c));
b=(atan2(e,e))+(atan(c));
d=fmax(c,d);
e=(atan2(a,c))-(fdim(c,e));
}
else{
a=(asin(a))-(pow(e,d));
d=tan(e);
c=(atan2(d,a))*(log10(c));
}
a=(exp(d))-(fmax(c,a));
b=fmax(a,c);
a=(pow(a,a))/(ceil(b));
}