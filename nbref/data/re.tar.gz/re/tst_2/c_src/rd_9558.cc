#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=atan(a);
e=exp(h);
h=(acos(a))+(fmax(d,e));
g=fmax(d,h);
c=fmax(g,g);
c=(floor(b))-(tan(f));
d=(fmax(a,f))/(cos(c));
d=atan2(g,c);
while(islessequal(b,h)){
d=pow(d,c);
a=(fmin(h,d))/(atan2(h,b));
b=(pow(g,b))*(log10(b));
}
}