#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(floor(a))+(exp(d));
f=(atan(a))*(fdim(a,b));
e=log10(d);
b=fmax(e,f);
if(islessgreater(a,d)){
c=sin(d);
b=(cos(a))-(pow(d,b));
a=(ceil(c))*(fmin(a,c));
d=cos(f);
}
else{
d=(fmax(c,f))/(cos(a));
d=fmin(d,c);
e=(pow(d,f))+(cos(c));
b=fmax(c,d);
e=log(a);
}
if(islessequal(d,f)){
e=atan(f);
f=atan(a);
f=sqrt(c);
b=ceil(a);
}
else{
a=(exp(a))/(atan2(a,e));
d=(ceil(f))+(atan2(c,a));
c=(acos(f))/(ceil(f));
d=fdim(f,b);
e=log10(b);
}
}