#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=(floor(c))-(cos(b));
c=sin(e);
e=(pow(b,b))-(pow(c,e));
b=tan(c);
a=(fdim(d,c))*(pow(d,b));
c=exp(c);
c=(sin(e))-(sqrt(b));
while(islessgreater(a,e)){
d=log10(a);
c=(atan2(d,b))*(exp(b));
c=fmax(a,a);
b=log10(d);
}
}