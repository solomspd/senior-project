#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=fmin(a,f);
c=floor(d);
if(islessequal(a,c)){
d=(pow(d,d))+(asin(b));
a=(pow(b,b))*(ceil(b));
a=fmin(f,c);
}
else{
c=(sin(a))+(pow(b,b));
f=fmax(c,a);
}
a=(ceil(b))*(atan2(d,b));
b=(acos(e))*(fmax(a,e));
e=(acos(d))/(cos(c));
e=pow(c,e);
}