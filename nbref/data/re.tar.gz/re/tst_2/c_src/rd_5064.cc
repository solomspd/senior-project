#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=tan(e);
d=sqrt(e);
d=tan(d);
a=fdim(c,b);
e=(floor(a))-(log(c));
a=exp(d);
e=(asin(d))-(log10(c));
while(islessgreater(d,a)){
d=(pow(d,e))+(pow(b,d));
b=(sin(c))/(tan(b));
}
}