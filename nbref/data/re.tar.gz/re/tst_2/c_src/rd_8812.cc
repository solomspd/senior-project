#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=sin(a);
e=(fmax(c,d))+(fmin(b,c));
a=(atan(e))-(acos(a));
c=exp(a);
c=pow(e,d);
b=(pow(a,b))*(log10(c));
a=fmax(c,b);
d=atan2(b,a);
d=(exp(b))-(fdim(e,d));
if(isless(b,a)){
d=(fmin(d,e))-(fmin(b,b));
d=fmin(e,e);
}
}