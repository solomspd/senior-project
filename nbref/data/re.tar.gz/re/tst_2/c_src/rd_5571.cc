#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=tan(b);
e=(exp(b))/(fdim(c,b));
a=fmin(d,a);
f=fmin(b,b);
f=(fmin(d,e))+(floor(b));
if(islessgreater(e,d)){
f=(fmax(f,f))/(pow(e,d));
f=fdim(f,a);
a=atan(f);
}
}