#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=fdim(c,d);
e=(pow(e,c))/(asin(d));
while(isgreaterequal(b,d)){
e=atan(d);
a=(pow(a,e))*(fmin(a,a));
b=log(b);
e=fmin(a,b);
}
if(islessgreater(a,c)){
e=(log(d))+(tan(d));
a=log10(a);
b=(acos(d))/(fmax(e,d));
b=(fmin(d,b))+(acos(a));
c=atan(a);
}
}