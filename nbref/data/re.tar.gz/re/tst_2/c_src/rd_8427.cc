#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=sqrt(f);
f=fmax(f,e);
c=pow(b,e);
c=(ceil(a))/(fmin(a,c));
while(islessgreater(a,c)){
b=atan2(a,f);
f=(fdim(a,e))*(atan2(b,f));
}
if(islessequal(b,a)){
e=fmax(d,e);
f=sqrt(e);
b=(sqrt(c))*(fmax(b,a));
}
}