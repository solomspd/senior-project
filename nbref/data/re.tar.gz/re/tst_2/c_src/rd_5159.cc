#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=(asin(c))*(pow(d,b));
d=sqrt(e);
g=(cos(d))/(acos(b));
c=fmin(e,g);
c=exp(b);
f=atan(f);
a=floor(g);
c=fdim(b,c);
f=sin(d);
while(islessgreater(d,b)){
b=(tan(g))*(sin(e));
g=(pow(d,c))+(fmax(g,e));
a=(pow(e,d))+(fdim(c,a));
}
}