#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=log10(a);
d=exp(e);
d=exp(e);
a=sin(d);
while(islessequal(c,a)){
f=asin(c);
e=atan2(e,b);
c=cos(e);
}
while(islessgreater(a,c)){
d=(ceil(f))-(log10(f));
a=(fmax(c,a))-(asin(c));
}
}