#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=asin(c);
d=(log10(b))-(cos(a));
e=fmax(d,a);
c=(pow(a,e))*(log10(e));
a=fmin(c,d);
while(isless(c,c)){
e=acos(a);
d=atan2(c,f);
b=ceil(a);
}
if(islessgreater(a,a)){
b=acos(c);
e=sin(e);
e=log(a);
f=log(a);
b=fmin(f,d);
}
else{
a=fmin(d,f);
a=exp(f);
}
}