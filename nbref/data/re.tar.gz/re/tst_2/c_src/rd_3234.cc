#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
f=(exp(b))*(acos(b));
a=tan(c);
while(islessequal(c,d)){
c=(fmin(b,d))*(floor(c));
d=(pow(d,d))-(log10(b));
}
if(islessgreater(f,b)){
d=(pow(a,e))-(atan2(b,a));
a=exp(e);
a=(pow(e,c))*(tan(b));
}
}