#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=acos(b);
b=(fmax(f,c))/(atan2(a,b));
c=sin(e);
a=(sin(e))*(atan(d));
b=(sin(e))*(fdim(a,d));
e=sqrt(e);
a=acos(c);
if(islessgreater(c,e)){
c=(sqrt(e))*(cos(a));
e=fmin(e,f);
e=atan2(c,c);
}
else{
d=(fmin(f,a))-(fmax(d,b));
e=(fdim(c,e))/(acos(c));
}
}