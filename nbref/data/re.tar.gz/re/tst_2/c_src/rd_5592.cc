#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
e=atan2(b,c);
b=(cos(e))-(tan(d));
c=(exp(b))+(pow(a,c));
d=atan2(b,c);
e=fmin(a,b);
d=fdim(b,e);
a=cos(a);
while(isless(d,e)){
b=cos(e);
d=(fmin(e,d))*(sqrt(e));
e=sin(e);
}
}