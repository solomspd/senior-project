#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=fmax(a,d);
g=ceil(d);
while(islessgreater(b,e)){
g=(pow(a,d))+(pow(g,b));
e=(fdim(a,f))+(log(g));
e=(log10(d))/(asin(c));
b=log10(g);
f=pow(g,g);
}
if(islessgreater(f,a)){
g=(fmax(d,f))-(sqrt(g));
g=ceil(b);
d=fmin(g,g);
b=cos(d);
}
else{
a=(sin(a))-(pow(d,d));
g=atan(f);
d=asin(g);
c=fmin(g,b);
f=(acos(f))/(asin(a));
}
}