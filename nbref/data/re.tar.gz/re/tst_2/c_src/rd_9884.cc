#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
d=(atan2(f,g))/(atan(h));
f=(exp(d))*(atan2(b,f));
d=exp(d);
h=fmin(d,d);
b=(atan(h))/(pow(g,h));
if(islessequal(d,f)){
g=fmin(d,b);
b=(asin(d))*(atan2(c,f));
f=(tan(b))/(floor(e));
}
if(islessequal(f,g)){
e=atan(f);
b=(tan(e))-(atan2(e,h));
e=(asin(a))-(atan2(e,a));
}
}