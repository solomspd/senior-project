#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=pow(b,c);
a=pow(c,a);
a=(fmax(e,b))+(cos(c));
c=(pow(d,a))-(pow(a,c));
f=(atan2(f,f))*(cos(a));
while(islessequal(c,c)){
d=pow(b,a);
a=(sqrt(c))*(fdim(e,f));
a=atan2(d,c);
d=sin(b);
}
b=log10(f);
b=(fmax(a,c))*(atan2(e,a));
a=pow(c,e);
f=pow(b,a);
e=floor(d);
}