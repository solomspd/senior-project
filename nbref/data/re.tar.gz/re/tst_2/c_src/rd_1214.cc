#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=(fmax(g,b))-(fmax(d,h));
b=(atan2(e,f))-(atan(b));
g=(fmax(e,f))/(fdim(a,e));
h=(atan(e))-(acos(a));
d=pow(g,c);
while(isless(c,c)){
c=fmin(c,d);
e=(atan2(d,h))*(asin(g));
f=fmax(b,h);
e=asin(a);
c=(pow(a,d))*(tan(h));
}
a=fdim(c,a);
g=(fmin(h,h))+(floor(b));
f=(atan(a))+(fmin(g,d));
h=(fmin(f,g))*(fmin(f,g));
f=atan(a);
}