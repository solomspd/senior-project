#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
b=acos(f);
f=asin(f);
d=(acos(a))/(sin(a));
f=acos(d);
b=sin(d);
b=pow(c,b);
f=asin(f);
b=cos(e);
d=(fdim(f,d))/(asin(b));
d=tan(d);
if(islessequal(b,a)){
d=atan(b);
c=pow(f,a);
e=(floor(b))+(cos(d));
d=(log10(c))*(acos(d));
c=floor(b);
}
else{
d=(ceil(d))+(atan(e));
a=(fdim(c,c))-(log(a));
a=(fdim(a,f))*(tan(a));
}
}