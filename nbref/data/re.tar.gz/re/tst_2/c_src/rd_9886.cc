#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=(exp(a))/(fdim(e,e));
a=(asin(a))/(atan2(d,e));
d=(tan(e))/(exp(e));
if(isless(c,c)){
a=sqrt(b);
c=fmax(c,a);
d=asin(a);
d=(fmin(e,d))*(log10(e));
}
if(islessgreater(e,c)){
b=(atan2(d,c))+(fdim(a,d));
a=(fdim(b,e))/(pow(e,b));
a=cos(b);
}
else{
c=sqrt(b);
e=(atan2(b,e))*(atan(c));
b=log10(d);
d=sin(c);
}
}