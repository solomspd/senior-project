#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=(fmax(b,a))/(tan(c));
f=(log(b))/(pow(b,d));
f=log(c);
d=(exp(a))/(fmin(c,a));
f=fmax(c,a);
b=tan(e);
f=tan(e);
while(isless(e,d)){
e=atan(e);
c=fmin(e,b);
b=(pow(f,f))/(pow(f,e));
e=fmax(d,f);
d=(sqrt(f))+(log(e));
}
}