#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(fmin(d,f))/(pow(c,d));
b=floor(e);
c=(pow(a,g))/(fmin(c,a));
while(islessequal(f,e)){
c=(pow(b,c))+(cos(b));
a=(log(a))-(atan2(e,f));
d=pow(f,a);
}
if(isgreaterequal(g,c)){
e=(log10(b))+(atan2(a,c));
c=(fdim(d,g))/(atan2(d,a));
g=fdim(c,g);
}
}