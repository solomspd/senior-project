#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=fmax(c,c);
a=pow(e,b);
a=fdim(b,b);
e=(fdim(e,e))*(asin(c));
while(isless(a,c)){
a=fmax(b,a);
a=(tan(d))+(exp(c));
}
a=(fmin(d,b))*(exp(a));
b=tan(c);
d=log(e);
d=fmax(b,d);
d=(tan(d))/(acos(e));
}