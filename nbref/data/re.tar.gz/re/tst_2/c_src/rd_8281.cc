#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
g=floor(b);
d=cos(b);
a=(sqrt(e))*(pow(g,f));
d=(log(f))+(atan(d));
while(islessequal(b,b)){
c=sqrt(a);
e=(sin(a))/(asin(g));
e=log10(c);
a=atan2(b,b);
}
while(isless(e,e)){
e=(fdim(e,f))/(fmin(g,g));
f=pow(e,e);
}
}