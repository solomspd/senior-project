#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
d=fmin(b,c);
d=fdim(b,a);
b=(ceil(e))-(tan(c));
if(islessequal(d,e)){
b=(log(b))*(ceil(d));
c=(fmin(b,d))/(pow(a,b));
c=atan2(b,a);
}
else{
e=(fmax(d,a))+(exp(b));
d=(log(d))-(fmin(a,a));
}
if(islessgreater(c,c)){
c=pow(a,e);
b=pow(e,c);
c=ceil(a);
c=ceil(b);
}
}