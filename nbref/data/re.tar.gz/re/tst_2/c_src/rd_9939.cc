#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=(acos(a))/(atan2(b,d));
e=sin(a);
if(isgreaterequal(c,a)){
e=log(e);
b=sqrt(d);
c=tan(a);
}
else{
d=atan2(d,e);
a=log(d);
d=atan(a);
d=ceil(b);
d=(fmin(d,c))/(tan(d));
}
while(islessgreater(b,e)){
a=(log10(d))/(log10(e));
b=fmin(b,b);
b=pow(a,e);
}
}