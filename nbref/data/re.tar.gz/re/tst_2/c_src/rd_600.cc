#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
a=(cos(d))/(atan(a));
a=(acos(b))-(fdim(a,e));
d=fmax(a,f);
e=(fmin(f,d))/(pow(e,e));
f=(fdim(a,a))+(fmax(e,e));
b=(log10(a))-(fmax(f,a));
f=ceil(c);
d=(exp(c))+(cos(d));
a=fdim(c,f);
c=(atan2(a,a))/(pow(f,f));
b=(floor(f))-(pow(e,f));
e=pow(f,c);
}