#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
d=fmin(c,a);
d=log10(e);
f=(exp(d))+(log(c));
e=(fmax(d,c))-(log10(b));
while(islessequal(f,c)){
e=(log10(a))-(fmin(d,a));
f=(log10(c))*(atan2(f,e));
d=(acos(f))+(fmin(e,f));
b=fmin(c,e);
}
b=floor(e);
d=(pow(e,f))-(fdim(b,a));
a=fdim(a,a);
e=asin(c);
}