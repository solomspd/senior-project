#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
c=atan2(c,c);
e=fmin(b,d);
c=cos(e);
f=fmax(f,g);
d=atan2(b,e);
g=(log10(f))+(fmin(f,f));
d=(sin(b))-(pow(g,d));
d=(pow(b,g))-(floor(b));
c=sqrt(g);
a=(log10(e))-(log(c));
b=fmax(a,d);
g=fmax(c,b);
}