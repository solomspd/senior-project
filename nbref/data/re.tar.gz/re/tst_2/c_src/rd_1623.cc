#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=fmax(e,d);
e=(floor(a))*(atan2(e,d));
b=(fdim(c,e))*(fmin(d,c));
c=floor(a);
c=(log10(d))+(exp(d));
while(isgreaterequal(b,c)){
e=(atan2(b,d))/(fmin(d,e));
c=(pow(c,a))-(atan(b));
e=(fmax(d,c))/(fdim(d,d));
b=(fmax(e,e))-(atan2(d,b));
b=log(e);
}
c=(atan(d))+(atan2(c,c));
e=(fdim(a,b))+(log(d));
}