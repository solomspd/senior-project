#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
c=fmin(b,e);
d=atan2(c,e);
a=pow(e,b);
a=fmin(d,e);
b=(sin(c))/(fmin(b,e));
e=(log(d))*(floor(e));
c=(atan2(a,b))-(log(d));
a=(fmax(d,c))+(fmin(b,d));
a=(exp(a))*(fmax(b,a));
a=acos(d);
a=(pow(d,a))-(log10(a));
}