#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
a=fdim(d,c);
f=(asin(a))+(fmin(g,e));
c=(fmax(b,d))-(exp(c));
a=(fmax(c,c))-(exp(d));
g=(floor(d))-(floor(f));
d=fmax(c,g);
e=fmax(f,d);
g=acos(c);
e=(cos(d))*(fmin(d,f));
b=(exp(a))*(asin(b));
c=fmax(f,a);
}