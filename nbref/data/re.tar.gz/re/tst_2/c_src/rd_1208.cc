#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
f=atan2(b,a);
e=fmin(e,c);
d=(pow(f,c))+(tan(f));
if(islessequal(g,f)){
d=fmax(d,a);
d=(sqrt(c))-(atan2(a,a));
f=(sin(e))+(fmax(f,f));
g=log(f);
}
else{
e=fmax(g,g);
c=log10(d);
d=(ceil(e))-(atan2(c,c));
}
if(isless(a,b)){
e=floor(f);
d=fmin(a,b);
g=acos(d);
}
else{
c=(exp(a))-(log10(d));
b=floor(a);
c=log10(c);
a=exp(a);
f=fmin(d,g);
}
}