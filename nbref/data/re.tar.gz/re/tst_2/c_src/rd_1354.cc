#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
c=(atan2(a,d))-(sqrt(a));
e=atan2(d,d);
e=(tan(b))-(ceil(a));
while(islessequal(e,f)){
e=pow(d,e);
b=atan2(e,c);
a=tan(b);
d=fmax(d,f);
}
if(islessequal(e,a)){
e=acos(d);
e=(fmax(e,a))+(acos(a));
f=asin(b);
c=fmin(c,e);
}
else{
b=(pow(c,b))*(tan(a));
c=(cos(b))*(atan(a));
}
}