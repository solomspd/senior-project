#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=pow(e,a);
d=(fmin(e,a))/(sqrt(b));
d=atan2(a,a);
e=(sqrt(a))-(fdim(e,e));
a=sqrt(e);
e=(log(c))+(pow(b,e));
c=(atan(d))*(log10(c));
b=atan2(e,c);
while(isgreaterequal(c,a)){
d=(fdim(e,b))+(atan2(c,b));
a=(ceil(e))*(atan(e));
b=atan(d);
c=(cos(d))+(ceil(b));
d=pow(e,c);
}
}