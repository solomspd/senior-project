#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
d=(fmin(b,a))/(pow(b,g));
e=log10(a);
b=fdim(f,a);
g=atan2(b,b);
c=atan(c);
e=atan2(g,a);
e=(exp(b))*(fmin(g,c));
c=cos(f);
f=(pow(a,f))+(asin(d));
e=(pow(b,d))/(asin(d));
g=(asin(g))-(exp(e));
}