#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
double f;
double g;
double h;
f=fmax(c,d);
g=(sin(e))+(ceil(h));
f=fmin(b,a);
c=cos(h);
d=(fmax(g,g))*(fdim(f,d));
f=(asin(c))*(fmax(a,f));
c=fmax(c,c);
h=sin(f);
h=(fdim(e,c))-(log(c));
f=(fmax(e,c))/(tan(c));
h=ceil(g);
}