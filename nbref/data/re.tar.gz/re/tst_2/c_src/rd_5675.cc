#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
b=tan(d);
d=fmin(d,a);
b=fdim(e,e);
while(islessequal(d,e)){
e=(atan2(e,a))+(fdim(e,a));
c=fmax(d,c);
e=(ceil(a))*(log(e));
c=(fmax(a,e))+(atan2(c,d));
}
if(islessgreater(c,b)){
e=(fdim(a,b))/(pow(c,b));
a=exp(d);
a=atan2(c,c);
}
}