#include <stdio.h>
#include <math.h>

int main(){
double a;
double b;
double c;
double d;
double e;
a=log10(a);
e=(sin(c))/(exp(c));
b=atan2(e,b);
a=(pow(d,d))-(sin(d));
b=(log10(c))-(pow(a,e));
c=fmax(d,b);
a=(cos(c))+(ceil(b));
}